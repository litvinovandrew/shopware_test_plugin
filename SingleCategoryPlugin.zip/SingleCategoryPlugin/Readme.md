# SingleCategoryPlugin
## About SingleCategoryPlugin
This skeleton contains a License file, fileheader and a basic README.

## License

Please see [License File](LICENSE) for more information.